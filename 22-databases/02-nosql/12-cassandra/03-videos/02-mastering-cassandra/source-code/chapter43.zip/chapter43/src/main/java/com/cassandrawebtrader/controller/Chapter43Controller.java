package com.cassandrawebtrader.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Chapter43Controller {
	
	private static Logger logger = LoggerFactory.getLogger(Chapter43Controller.class);
	
	@RequestMapping("/")
	public String index() {
		logger.info("/ is called");
		
		return "index";
	}

}
