package com.cassandrawebtrader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter42Application {

    public static void main(String[] args) {
        SpringApplication.run(Chapter42Application.class, args);
    }
}
