package com.cassandrawebtrader.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

@Component
public class EmailService {
	
	private static Logger logger = LoggerFactory.getLogger(EmailService.class);
	
	@ServiceActivator(inputChannel="outputChannel")
	public void sendEmail(String value) {
		logger.info("To: kan@cassandrawebtrader.com");
		logger.info("From: kan@cassandrawebtrader.com");
		logger.info("Subject: Trading Signal Alert");
		logger.info("Body: " + value);
	}

}
