package com.cassandrawebtrader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

@SpringBootApplication
public class Chapter45Application {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(Chapter45Application.class, args);
        
        MessageChannel channel = ctx.getBean("inputChannel", MessageChannel.class);
        
        Message<String> message = MessageBuilder.withPayload("AAPL@100.00").build();
        
        channel.send(message);
        
        ctx.close();
    }
}
