package com.cassandrawebtrader.service;

import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Service;

@Service
public class TradingAlertService {
	
	@ServiceActivator(inputChannel="inputChannel", outputChannel="outputChannel")
	public String tradingSignalAlert(String name) {
		return "Trading Signal Alert: " + name + " !";
	}

}
