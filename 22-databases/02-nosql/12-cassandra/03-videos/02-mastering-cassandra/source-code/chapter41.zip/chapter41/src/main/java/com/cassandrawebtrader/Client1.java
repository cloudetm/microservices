package com.cassandrawebtrader;

import org.springframework.stereotype.Component;

@Component
public class Client1 implements Client {
	
	/* (non-Javadoc)
	 * @see com.cassandrawebtrader.Client#saySomething()
	 */
	@Override
	public void saySomething() {
		System.out.println("This is Client1");
	}

}
