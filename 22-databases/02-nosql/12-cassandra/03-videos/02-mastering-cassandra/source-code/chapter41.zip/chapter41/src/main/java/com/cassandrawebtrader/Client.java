package com.cassandrawebtrader;

public interface Client {

	void saySomething();

}