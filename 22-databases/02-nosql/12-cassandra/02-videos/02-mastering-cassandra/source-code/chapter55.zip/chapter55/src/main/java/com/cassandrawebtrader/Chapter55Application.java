package com.cassandrawebtrader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cassandra.core.cql.CqlIdentifier;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.cassandra.core.CassandraAdminOperations;
import com.cassandrawebtrader.domain.Event;

@SpringBootApplication
public class Chapter55Application {

	private static Logger logger = LoggerFactory.getLogger(Chapter55Application.class);
	
    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(Chapter55Application.class, args);

        CassandraAdminOperations cassandraAdminOperations = ctx.getBean(CassandraAdminOperations.class);
        
        CqlIdentifier tableName = new CqlIdentifier("event");
        
        cassandraAdminOperations.createTable(true, tableName, Event.class, null);
        
        String metadata = cassandraAdminOperations.getTableMetadata("cwt", tableName).exportAsString();
        
        logger.info(metadata);
        
        ctx.close();
    }
}
