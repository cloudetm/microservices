package com.cassandrawebtrader.dao;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.cassandrawebtrader.domain.Person;

public interface PersonRepository extends CassandraRepository<Person> {
	
	@Query("select * from person where id = ?0")
	public Person findOne(String id);

}
