package com.cassandrawebtrader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import com.cassandrawebtrader.dao.PersonRepository;
import com.cassandrawebtrader.domain.Person;

@SpringBootApplication
public class Chapter54Application {

	private static Logger logger = LoggerFactory.getLogger(Chapter54Application.class);
	
    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(Chapter54Application.class, args);

        PersonRepository personRepository = ctx.getBean(PersonRepository.class);
        personRepository.save(new Person("9876543210", "Mary", 20));
        
        Person person = personRepository.findOne("9876543210");
        
        logger.info(person.toString());
        
        ctx.close();
    }
}
