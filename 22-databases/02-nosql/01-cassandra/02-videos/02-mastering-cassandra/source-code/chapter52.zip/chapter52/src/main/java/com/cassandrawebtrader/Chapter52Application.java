package com.cassandrawebtrader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cassandra.core.CqlOperations;
import org.springframework.cassandra.core.CqlTemplate;
import org.springframework.context.ConfigurableApplicationContext;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.Statement;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;

@SpringBootApplication
public class Chapter52Application {

	private static Logger logger = LoggerFactory.getLogger(Chapter52Application.class);
	
	private static Cluster cluster;
	private static Session session;
	
    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(Chapter52Application.class, args);
        
        cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
        session = cluster.connect("cwt");
        
        CqlOperations cops = new CqlTemplate(session);
        
        String example1 = "insert into person (id, name, age) values ('1234567890', 'David', 40);";
        cops.execute(example1);

        Insert example2 = QueryBuilder.insertInto("person")
        					.value("id", "2345678901")
        					.value("name", "John")
        					.value("age", 39);
        cops.execute(example2);
        
        Statement example3 = cops.getSession()
        						.prepare("insert into person (id, name, age) values (?, ?, ?)")
        						.bind("3456789012", "Peter", 38);
        cops.execute(example3);
        
        ResultSet rs3 = cops.query("select * from person");
        while (!rs3.isExhausted()) {
        	Row r = rs3.one();
        	String id = r.getString("id");
        	String name = r.getString("name");
        	Integer age = r.getInt("age");
        	
        	logger.info("id: " + id + ", name: " + name + ", age: " + age.toString());
        }
        
        cluster.close();
        
        ctx.close();
    }
}
