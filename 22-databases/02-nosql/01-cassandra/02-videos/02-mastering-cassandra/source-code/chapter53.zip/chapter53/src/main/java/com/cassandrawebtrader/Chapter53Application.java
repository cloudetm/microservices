package com.cassandrawebtrader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.cassandra.core.CassandraOperations;
import org.springframework.data.cassandra.core.CassandraTemplate;

import com.cassandrawebtrader.domain.Person;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;

@SpringBootApplication
public class Chapter53Application {

	private static Logger logger = LoggerFactory.getLogger(Chapter53Application.class);
	
	private static Cluster cluster;
	private static Session session;
	
    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(Chapter53Application.class, args);
        
        cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
        session = cluster.connect("cwt");

        CassandraOperations ops = new CassandraTemplate(session);
        
        ops.insert(new Person("1111111", "Mary", 55));
        
        Select s = QueryBuilder.select().from("person");
        s.where(QueryBuilder.eq("id", "1111111"));
        
        Person p = ops.selectOne(s, Person.class);
        
        logger.info("id: " + p.getId() + ", name: " + p.getName() + ", age: " + p.getAge().toString());
        
        cluster.close();
        
        ctx.close();
    }
}
